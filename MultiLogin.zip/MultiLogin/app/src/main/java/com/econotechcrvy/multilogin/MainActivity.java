package com.econotechcrvy.multilogin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    // region Constantes
    private static final int RC_SIGN_IN = 123;
    private static final String UNKNOWN_PROVIDER = "Proveedor desconocido";
    private static final String PASSWORD_FIREBASE = "firebase";
    // endregion
    // region Variables privadas
    private FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    // endregion
    // region UI variables
    private TextView tvUserName, tvEmail, tvProvider;
    private ImageView imgPhotoProfile;
    // endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onCreateFunctions();
    }



    // region Overrides
    @Override
    protected void onResume() {
        super.onResume();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (mAuthStateListener != null) {
            mFirebaseAuth.removeAuthStateListener(mAuthStateListener);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            if (resultCode == RESULT_OK) { // Ya se tiene iniciada la sesion, aqui se guardan los datos, cambia actividad, enviar mensaje de bienvenida
                Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Error al iniciar sesion, intente de nuevo", Toast.LENGTH_SHORT).show();
            }
        }
    }
    // endregion

    // region Funciones onCreate
    private void onCreateFunctions(){
        setUiVariables();
        startFirebaseAuth();
    }
    private void startFirebaseAuth() {
        mFirebaseAuth = FirebaseAuth.getInstance();
        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) { // Se ejecuta cada que se inicie o cierre sesión
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    onSetDataUser(user.getDisplayName(), user.getEmail(),
                            user.getProviderId() != null? user.getProviderId() : UNKNOWN_PROVIDER);
                } else {
                    startActivityForResult(AuthUI.getInstance()
                            .createSignInIntentBuilder().setIsSmartLockEnabled(false) // False = no recordara contraseña y usuario
                            .setTosAndPrivacyPolicyUrls("https://www.alternativaturistica.com/terminos-y-condiciones",
                                    "https://www.alternativaturistica.com/aviso-de-privacidad")
                            .setAvailableProviders(Arrays.asList(new AuthUI.IdpConfig.EmailBuilder().build()))
                            .build(), RC_SIGN_IN); // URL de la politica de privacidad
                }
            }
        };
    }
    private void setUiVariables(){
        tvUserName = findViewById(R.id.tvUserName);
        tvEmail = findViewById(R.id.tvEmail);
        tvProvider = findViewById(R.id.tvProvider);
        imgPhotoProfile = findViewById(R.id.imgPhotoProfile);
    }
    //endregion

    // region Funciones Auxiliares
    private void onSetDataUser(String userName, String eMail, String provider) {
        tvUserName.setText(getString(R.string.main_hint_userName) + " " + userName);
        tvEmail.setText(getString(R.string.main_hint_userMail) + " " + eMail);

        int drawableRes = getProviderDrawableRes(provider);
        if (drawableRes == R.drawable.ic_unknown_provider) { provider = UNKNOWN_PROVIDER; }
        tvProvider.setCompoundDrawablesRelativeWithIntrinsicBounds(drawableRes, 0,0,0);
        tvProvider.setText(getString(R.string.main_hint_provider) + " " + provider);

    }

    private int getProviderDrawableRes(String provider){
        Log.d("Proveedor pasado", provider);
        switch(provider){
            case PASSWORD_FIREBASE:
                return R.drawable.ic_email;
            default:
                return R.drawable.ic_unknown_provider;
        }
    }
    // endregion
}